<?php

namespace CoinGate\APIError;

# HTTP Status 422
class UnprocessableEntity extends APIError
{
}
