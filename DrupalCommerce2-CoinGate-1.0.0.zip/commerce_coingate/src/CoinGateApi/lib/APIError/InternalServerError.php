<?php

namespace CoinGate\APIError;

# HTTP Status 500, 504
class InternalServerError extends APIError
{
}
